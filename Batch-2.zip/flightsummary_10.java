package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;

public class flightsummary_10 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					flightsummary_10 window = new flightsummary_10();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public flightsummary_10() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 869, 734);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Flight Summary");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(47, 50, 235, 44);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Flight");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1.setBounds(376, 103, 235, 44);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Available");
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_2.setBounds(492, 103, 235, 44);
		frame.getContentPane().add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("Booked");
		lblNewLabel_1_1_3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_3.setBounds(677, 103, 178, 44);
		frame.getContentPane().add(lblNewLabel_1_1_3);
		
		JLabel lblNewLabel_1_1_4 = new JLabel("Seat");
		lblNewLabel_1_1_4.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_4.setBounds(47, 230, 235, 44);
		frame.getContentPane().add(lblNewLabel_1_1_4);
		
		JLabel lblNewLabel_1_1_5 = new JLabel("First Name");
		lblNewLabel_1_1_5.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_5.setBounds(193, 230, 235, 44);
		frame.getContentPane().add(lblNewLabel_1_1_5);
		
		JLabel lblNewLabel_1_1_5_1 = new JLabel("Last Name");
		lblNewLabel_1_1_5_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_5_1.setBounds(376, 230, 235, 44);
		frame.getContentPane().add(lblNewLabel_1_1_5_1);
		
		JLabel lblNewLabel_1_1_5_2 = new JLabel("Passport Number");
		lblNewLabel_1_1_5_2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_5_2.setBounds(577, 230, 235, 44);
		frame.getContentPane().add(lblNewLabel_1_1_5_2);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		lblNewLabel.setBounds(688, 22, 138, 56);
		frame.getContentPane().add(lblNewLabel);
	}

}
