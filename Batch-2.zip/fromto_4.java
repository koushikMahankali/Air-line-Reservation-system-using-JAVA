package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

import java.awt.Font;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JMenu;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
class tripDetails implements Serializable{
	 String from,to,depdate,redate,seat,fname,lname,passnumber;
	 tripDetails(String from,String to,String depdate,String redate,String seat,String fname,String lname,String passnumber){
		 this.from = from ;
		 this.to = to;
         this.depdate=depdate;
         this.redate=redate;
         this.seat=seat;
         this.fname=fname;
         this.lname=lname;
         this.passnumber=passnumber;
	 }
	public String getFrom() {
		return from;
	}
	public String getTo() {
		return to;
	}
	public String getDepdate() {
		return depdate;
	}
	public String getRedate() {
		return redate;
	}
	public String getSeat() {
		return seat;
	}
	public String getFname() {
		return fname;
	}
	public String getLname() {
		return lname;
	}
	public String getPassnumber() {
		return passnumber;
	}

	
} 
public class fromto_4 {

	private JFrame frmFromtopage;
	private JLabel lblNewLabel_1_1;
	private JLabel lblNewLabel_1_1_1;
	private JTextField fromf;
	private JTextField tof;
	private JTextField dedf;
	private JTextField redf;
	private JTextField seatf;
	private JTextField fnamef;
	private JTextField lnamef;
	private JTextField passf;

	private FileOutputStream fout;
	private ObjectOutputStream oos;
	private FileInputStream fin;
	private ObjectInputStream ois;

	File file;
    ArrayList<tripDetails> al;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					fromto_4 window = new fromto_4();
					window.frmFromtopage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public fromto_4() {
		initialize();
		frmFromtopage.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		al = new ArrayList<tripDetails>();
		frmFromtopage = new JFrame();
		frmFromtopage.setTitle("fromtopage");
		frmFromtopage.setBounds(100, 100, 1286, 895);
		frmFromtopage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmFromtopage.getContentPane().setLayout(null);
		
		lblNewLabel_1_1 = new JLabel("From");
		lblNewLabel_1_1.setBounds(69, 47, 83, 44);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmFromtopage.getContentPane().add(lblNewLabel_1_1);
		
		lblNewLabel_1_1_1 = new JLabel("To");
		lblNewLabel_1_1_1.setBounds(548, 47, 59, 44);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmFromtopage.getContentPane().add(lblNewLabel_1_1_1);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.setBounds(920, 678, 129, 44);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new departure_6();
				frmFromtopage.setVisible(false);
				JTextComponent t1;
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmFromtopage.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(1083, 47, 138, 56);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		frmFromtopage.getContentPane().add(lblNewLabel);
		
		fromf = new JTextField();
		fromf.setBounds(294, 66, 152, 19);
		frmFromtopage.getContentPane().add(fromf);
		fromf.setColumns(10);
		
		tof = new JTextField();
		tof.setBounds(759, 66, 152, 19);
		tof.setColumns(10);
		frmFromtopage.getContentPane().add(tof);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Departure Date");
		lblNewLabel_1_1_2.setBounds(68, 119, 188, 44);
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmFromtopage.getContentPane().add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Return Date");
		lblNewLabel_1_1_1_1.setBounds(548, 119, 188, 44);
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmFromtopage.getContentPane().add(lblNewLabel_1_1_1_1);
		
		dedf = new JTextField();
		dedf.setBounds(294, 138, 152, 19);
		dedf.setColumns(10);
		frmFromtopage.getContentPane().add(dedf);
		
		redf = new JTextField();
		redf.setBounds(759, 138, 152, 19);
		redf.setColumns(10);
		frmFromtopage.getContentPane().add(redf);
		
		JButton btnCanceel = new JButton("Cancel");
		btnCanceel.setBounds(450, 710, 114, 21);
		btnCanceel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		frmFromtopage.getContentPane().add(btnCanceel);
		
		JLabel lblNewLabel_1 = new JLabel("Seats");
		lblNewLabel_1.setBounds(69, 199, 138, 29);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmFromtopage.getContentPane().add(lblNewLabel_1);
		
		seatf = new JTextField();
		seatf.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				char cn = e.getKeyChar();
				if(Character.isDigit(cn)) {
					fnamef.setEditable(false);
					JOptionPane.showMessageDialog(null,"please enter the seat number");
					fnamef.setEditable(true);
				}
				else
				{
					fnamef.setEditable(true);
				}
			}
		});
		seatf.setBounds(294, 210, 96, 19);
		seatf.setColumns(10);
		frmFromtopage.getContentPane().add(seatf);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("Passenger Details");
		lblNewLabel_1_1_3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_3.setBounds(69, 312, 235, 44);
		frmFromtopage.getContentPane().add(lblNewLabel_1_1_3);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("First Name");
		lblNewLabel_1_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1_2.setBounds(201, 401, 161, 44);
		frmFromtopage.getContentPane().add(lblNewLabel_1_1_1_2);
		
		fnamef = new JTextField();
		fnamef.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				char cn = e.getKeyChar();
				if(Character.isDigit(cn)) {
					fnamef.setEditable(false);
					JOptionPane.showMessageDialog(null,"Enter Valid Name");
					fnamef.setEditable(true);
				}
				else
				{
					fnamef.setEditable(true);
				}
			}
		});
		fnamef.setColumns(10);
		fnamef.setBounds(404, 405, 271, 49);
		frmFromtopage.getContentPane().add(fnamef);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Last Name");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1_1_1.setBounds(201, 508, 161, 44);
		frmFromtopage.getContentPane().add(lblNewLabel_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_2_1 = new JLabel("Passport Number");
		lblNewLabel_1_1_1_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1_2_1.setBounds(179, 597, 279, 44);
		frmFromtopage.getContentPane().add(lblNewLabel_1_1_1_2_1);
		
		lnamef = new JTextField();
		lnamef.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				char cn = e.getKeyChar();
				if(Character.isDigit(cn)) {
					lnamef.setEditable(false);
					JOptionPane.showMessageDialog(null,"Enter Valid Name");
					lnamef.setEditable(true);
				}
				else
				{
					lnamef.setEditable(true);
				}
			}
		});
		lnamef.setColumns(10);
		lnamef.setBounds(404, 508, 271, 49);
		frmFromtopage.getContentPane().add(lnamef);
		
		passf = new JTextField();
		passf.setColumns(10);
		passf.setBounds(404, 592, 271, 49);
		frmFromtopage.getContentPane().add(passf);
		JLabel lblNewLabel_1_1_5 = new JLabel("Booking");
		lblNewLabel_1_1_5.setBounds(69, 10, 123, 44);
		lblNewLabel_1_1_5.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmFromtopage.getContentPane().add(lblNewLabel_1_1_5);
		
		JButton btnNewButton_1 = new JButton("Book");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				file = new File("./TripDetails.dat");
        		String from = fromf.getText();
        		String to = tof.getText();
        		String depdate = dedf.getText();
        		String redate=redf.getText();
        		String seat = seatf.getText();
        		String fname = fnamef.getText();
        		String lname = lnamef.getText();
        		String passnumber = passf.getText();
        		 
        		al.add(new tripDetails(from,to,depdate,redate,seat,fname,lname,passnumber));
        		System.out.println(al);
        		fromf.setText("");
        		tof.setText("");
        		dedf.setText("");
        		redf.setText("");
        		seatf.setText("");
        		fnamef.setText("");
        		lnamef.setText("");
        		passf.setText("");
        		try {
        			
        			if(file.exists()) {
        		
        				oos = new ObjectOutputStream(new FileOutputStream(file,true)){
        					
        					protected void writeStreamHeader() throws java.io.IOException{
        						reset();
        					}
        				};
        				
        			}
        			else {
        				oos = new ObjectOutputStream(new FileOutputStream(file));
        				
        			
        			} 
        			oos.writeObject(al);
        			JOptionPane.showMessageDialog(null, "Booking sucess");
        		
        		}
        		catch(Exception ae) {
        			ae.printStackTrace();
        		}
			}
		});
		btnNewButton_1.setBounds(229, 710, 85, 21);
		btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		frmFromtopage.getContentPane().add(btnNewButton_1);
	
	}
}

