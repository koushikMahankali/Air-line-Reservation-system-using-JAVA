package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class bookingsummary_9 {

	private JFrame frmBookingsummary;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bookingsummary_9 window = new bookingsummary_9();
					window.frmBookingsummary.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public bookingsummary_9() {
		initialize();
		frmBookingsummary.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmBookingsummary = new JFrame();
		frmBookingsummary.setTitle("Bookingsummary");
		frmBookingsummary.setBounds(100, 100, 856, 706);
		frmBookingsummary.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmBookingsummary.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Booking Summary");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(25, 28, 235, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("From");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1.setBounds(331, 70, 235, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("To");
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_2.setBounds(576, 70, 235, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("First Name");
		lblNewLabel_1_1_3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_3.setBounds(25, 179, 235, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1_3);
		
		JLabel lblNewLabel_1_1_4 = new JLabel("Last Name");
		lblNewLabel_1_1_4.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_4.setBounds(25, 305, 235, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1_4);
		
		JLabel lblNewLabel_1_1_5 = new JLabel("Passport Number");
		lblNewLabel_1_1_5.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_5.setBounds(25, 456, 235, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1_5);
		
		JLabel lblNewLabel_1_1_6 = new JLabel("Date");
		lblNewLabel_1_1_6.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_6.setBounds(331, 217, 235, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1_6);
		
		JLabel lblNewLabel_1_1_9 = new JLabel("Flight");
		lblNewLabel_1_1_9.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_9.setBounds(331, 367, 113, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1_9);
		
		JLabel lblNewLabel_1_1_10 = new JLabel("Seat");
		lblNewLabel_1_1_10.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_10.setBounds(537, 367, 235, 44);
		frmBookingsummary.getContentPane().add(lblNewLabel_1_1_10);
		
		JButton btnNewButton = new JButton("Close");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmBookingsummary.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(581, 583, 140, 33);
		frmBookingsummary.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		lblNewLabel.setBounds(673, 16, 138, 56);
		frmBookingsummary.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(320, 124, 154, 33);
		frmBookingsummary.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(551, 130, 170, 27);
		frmBookingsummary.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(309, 514, 351, 33);
		frmBookingsummary.getContentPane().add(textField_2);
	}
}
