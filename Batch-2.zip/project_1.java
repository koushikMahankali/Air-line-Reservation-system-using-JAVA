package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;



import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JPasswordField;
import javax.swing.JFormattedTextField;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

class AdminLogin implements Serializable{
	 String username,password;
	 AdminLogin(String username,String password){
		 this.username = username ;
		 this.password = password;

	 }
	public String getusername() {
		return username;
	}
	public String getpassword() {
		return password;
	}
	
} 
public class project_1 {

	private JFrame frmLoginpage;
	private JPasswordField passwordField;
	private FileOutputStream fout;
	private ObjectOutputStream oos;
	private FileInputStream fin;
	private ObjectInputStream ois;

	File file;
    ArrayList<AdminLogin> al;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					project_1 window = new project_1();
					window.frmLoginpage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public project_1() {
		initialize();
		frmLoginpage.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		al = new ArrayList<AdminLogin>();
		frmLoginpage = new JFrame();
		frmLoginpage.setTitle("loginpage");
		frmLoginpage.setBounds(100, 100, 826, 490);
		frmLoginpage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLoginpage.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		lblNewLabel.setBounds(666, 10, 136, 63);
		frmLoginpage.getContentPane().add(lblNewLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(322, 256, 165, 19);
		frmLoginpage.getContentPane().add(passwordField);
		
		JLabel lblNewLabel_1 = new JLabel("Login");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(377, 89, 86, 44);
		frmLoginpage.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Username");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(167, 162, 123, 44);
		frmLoginpage.getContentPane().add(lblNewLabel_1_1);
		
		JTextArea textArea = new JTextArea();
		textArea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				char cn = e.getKeyChar();
				if(Character.isDigit(cn)) {
					textArea.setEditable(false);
					JOptionPane.showMessageDialog(null,"Enter Valid Name");
					textArea.setEditable(true);
				}
				else
				{
					textArea.setEditable(true);
				}
			}
		});
		textArea.setBounds(322, 178, 165, 22);
		frmLoginpage.getContentPane().add(textArea);

		JLabel lblNewLabel_1_1_1 = new JLabel("Password");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1.setBounds(167, 248, 123, 44);
		frmLoginpage.getContentPane().add(lblNewLabel_1_1_1);
		JButton btnNewButton = new JButton("Login");
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean flag = false;
        		try {
        			file = new File("./LoginDetails.dat");
        			fin = new FileInputStream(file);
        			ois = new ObjectInputStream(fin);
        			ArrayList<AdminLogin> al = new ArrayList<AdminLogin>();
        			String username = textArea.getText();
            		@SuppressWarnings("deprecation")
					String password = passwordField.getText();
            		while((al = (ArrayList)ois.readObject())!=null) {
            			AdminLogin e1 = al.get(0);
            			if(username.equalsIgnoreCase(e1.getusername()) && password.equals(e1.getpassword())) {
            				flag = true;
            				break;
            				
            			}
            			else
            				flag = false;
           
            		}
            		if(flag = true) {
            		JOptionPane.showMessageDialog(null, "Login Success");
            		
    				new fromto_4();
    				frmLoginpage.setVisible(false);
            		}
            		else
            			JOptionPane.showMessageDialog(null, "Login Fail");
            		
        		}
        		catch(Exception ae) {
        			JOptionPane.showMessageDialog(null, "No User Found");
        	
        			}
        		
        		

			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(380, 353, 107, 38);
		frmLoginpage.getContentPane().add(btnNewButton);
		

		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Show/Hide Password");
		chckbxNewCheckBox.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		chckbxNewCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JCheckBox c = (JCheckBox) e.getSource();
				passwordField.setEchoChar(c.isSelected()?'\u0000':(Character)UIManager.get("PasswordField.echoChar"));
				
			}
		});
		chckbxNewCheckBox.setBounds(248, 313, 215, 21);
		frmLoginpage.getContentPane().add(chckbxNewCheckBox);
		
		JButton registerButton = new JButton("Register");
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				file = new File("LoginDetails.dat");
        		String username = textArea.getText();
        		String password = passwordField.getText();
        		
        		 
        		al.add(new AdminLogin(username,password));
        		System.out.println(al);
        		textArea.setText("");
        		passwordField.setText("");
        		
        		try {
        			
        			if(file.exists()) {
        		
        				oos = new ObjectOutputStream(new FileOutputStream(file,true)){
        					
        					protected void writeStreamHeader() throws java.io.IOException{
        						reset();
        					}
        				};
        				
        			}
        			else {
        				oos = new ObjectOutputStream(new FileOutputStream(file));
        				
        			
        			} 
        			oos.writeObject(al);
        			JOptionPane.showMessageDialog(null, "Registration sucess");
        		
        		}
        		catch(Exception ae) {
        			ae.printStackTrace();
        		}
			}
		});
		registerButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		registerButton.setBounds(178, 353, 107, 38);
		frmLoginpage.getContentPane().add(registerButton);
		
	}
}