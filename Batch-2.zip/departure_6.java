package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class departure_6 {

	private JFrame frmBbokingpage;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					departure_6 window = new departure_6();
					window.frmBbokingpage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public departure_6() {
		initialize();
		frmBbokingpage.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmBbokingpage = new JFrame();
		frmBbokingpage.setTitle("bbokingpage");
		frmBbokingpage.setBounds(100, 100, 879, 636);
		frmBbokingpage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmBbokingpage.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Departure");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(42, 26, 123, 44);
		frmBbokingpage.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("From");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1.setBounds(196, 111, 123, 44);
		frmBbokingpage.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("To");
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_2.setBounds(434, 111, 123, 44);
		frmBbokingpage.getContentPane().add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_5 = new JLabel("Booking");
		lblNewLabel_1_1_5.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_5.setBounds(172, 321, 123, 44);
		frmBbokingpage.getContentPane().add(lblNewLabel_1_1_5);
		
		JButton btnNewButton = new JButton("Book");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new passengerdetails_8 ();
				frmBbokingpage.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(323, 382, 85, 21);
		frmBbokingpage.getContentPane().add(btnNewButton);
		
		JButton btnCanceel = new JButton("Cancel");
		btnCanceel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnCanceel.setBounds(466, 382, 114, 21);
		frmBbokingpage.getContentPane().add(btnCanceel);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		lblNewLabel.setBounds(689, 26, 138, 56);
		frmBbokingpage.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1_1_3_1 = new JLabel("Date");
		lblNewLabel_1_1_3_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_3_1.setBounds(172, 228, 123, 44);
		frmBbokingpage.getContentPane().add(lblNewLabel_1_1_3_1);
		
		JLabel lblNewLabel_1 = new JLabel("Seats");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(170, 427, 138, 29);
		frmBbokingpage.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Adults");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(296, 466, 123, 35);
		frmBbokingpage.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(455, 476, 96, 19);
		frmBbokingpage.getContentPane().add(textField);
		
		JLabel lblNewLabel_2_1 = new JLabel("Children");
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(296, 527, 123, 35);
		frmBbokingpage.getContentPane().add(lblNewLabel_2_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(455, 537, 96, 19);
		frmBbokingpage.getContentPane().add(textField_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Children");
		lblNewLabel_2_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_2_1_1.setBounds(455, 527, 123, 35);
		frmBbokingpage.getContentPane().add(lblNewLabel_2_1_1);
	}
}
