package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

public class seat_7 {

	private JFrame frmSeatpage;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					seat_7 window = new seat_7();
					window.frmSeatpage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public seat_7() {
		initialize();
		frmSeatpage.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSeatpage = new JFrame();
		frmSeatpage.setTitle("seatpage");
		frmSeatpage.setBounds(100, 100, 875, 753);
		frmSeatpage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSeatpage.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Seats");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel.setBounds(64, 275, 138, 29);
		frmSeatpage.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new passengerdetails_8();
				frmSeatpage.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(714, 627, 85, 21);
		frmSeatpage.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		lblNewLabel_1.setBounds(679, 40, 138, 56);
		frmSeatpage.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(414, 343, 96, 19);
		frmSeatpage.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Adults");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(170, 346, 123, 35);
		frmSeatpage.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Children");
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(170, 450, 123, 35);
		frmSeatpage.getContentPane().add(lblNewLabel_2_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(414, 460, 96, 19);
		frmSeatpage.getContentPane().add(textField_1);
	}
}
