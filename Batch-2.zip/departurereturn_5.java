package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class departurereturn_5 {

	private JFrame frmDeparturepage;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					departurereturn_5 window = new departurereturn_5();
					window.frmDeparturepage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public departurereturn_5() {
		initialize();
		frmDeparturepage.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmDeparturepage = new JFrame();
		frmDeparturepage.setTitle("departurepage");
		frmDeparturepage.setBounds(100, 100, 832, 686);
		frmDeparturepage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmDeparturepage.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Departure Date");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(178, 159, 188, 44);
		
		frmDeparturepage.getContentPane().add(lblNewLabel_1_1);
		JLabel lblNewLabel_1_1_1 = new JLabel("Return Date");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1.setBounds(178, 268, 188, 44);
		frmDeparturepage.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		lblNewLabel.setBounds(633, 43, 138, 56);
		frmDeparturepage.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new departure_6 ();
				frmDeparturepage.setVisible(false);
			}
		});
		btnNewButton.setBounds(620, 567, 126, 30);
		frmDeparturepage.getContentPane().add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(464, 178, 176, 19);
		frmDeparturepage.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(464, 287, 176, 19);
		frmDeparturepage.getContentPane().add(textField_1);
		textField_1.setColumns(10);
	}
}
