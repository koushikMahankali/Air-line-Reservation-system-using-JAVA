package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class welcome_0 {

	private JFrame frmWelcomepage;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					welcome_0 window = new welcome_0();
					window.frmWelcomepage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public welcome_0() {
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmWelcomepage = new JFrame();
		frmWelcomepage.setTitle("welcomepage");
		frmWelcomepage.setBackground(Color.WHITE);
		frmWelcomepage.setBounds(100, 100, 806, 535);
		frmWelcomepage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmWelcomepage.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Welcome to Airline Reservation ");
		lblNewLabel_1_1.setBounds(207, 116, 436, 191);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmWelcomepage.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("System");
		lblNewLabel_1_1_1.setBounds(312, 245, 94, 44);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		frmWelcomepage.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(607, 47, 138, 56);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		frmWelcomepage.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.setBounds(628, 393, 113, 32);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new project_1 ();
				frmWelcomepage.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		frmWelcomepage.getContentPane().add(btnNewButton);
	}
}
