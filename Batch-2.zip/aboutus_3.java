package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class aboutus_3 {

	private JFrame frmAboutpage;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					aboutus_3 window = new aboutus_3();
					window.frmAboutpage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public aboutus_3() {
		initialize();
		frmAboutpage.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAboutpage = new JFrame();
		frmAboutpage.setTitle("aboutpage");
		frmAboutpage.setBounds(100, 100, 772, 300);
		frmAboutpage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAboutpage.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Domestic");
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(114, 105, 141, 21);
		frmAboutpage.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		lblNewLabel.setBounds(575, 20, 141, 58);
		frmAboutpage.getContentPane().add(lblNewLabel);
	}
}
