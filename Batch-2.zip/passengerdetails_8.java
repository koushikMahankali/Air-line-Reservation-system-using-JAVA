package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class passengerdetails_8 {

	private JFrame frmPassengerpage;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					passengerdetails_8 window = new passengerdetails_8();
					window.frmPassengerpage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public passengerdetails_8() {
		initialize();
		 frmPassengerpage.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPassengerpage = new JFrame();
		frmPassengerpage.setTitle("passengerpage");
		frmPassengerpage.getContentPane().setFont(new Font("Times New Roman", Font.PLAIN, 20));
		frmPassengerpage.setBounds(100, 100, 846, 623);
		frmPassengerpage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPassengerpage.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Passenger Details");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(44, 32, 235, 44);
		frmPassengerpage.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("First Name");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1.setBounds(44, 130, 161, 44);
		frmPassengerpage.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Last Name");
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1_1.setBounds(44, 277, 161, 44);
		frmPassengerpage.getContentPane().add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("Passport Number");
		lblNewLabel_1_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_1_1_1_2.setBounds(44, 411, 279, 44);
		frmPassengerpage.getContentPane().add(lblNewLabel_1_1_1_2);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				char cn = e.getKeyChar();
				if(Character.isDigit(cn)) {
					textField.setEditable(false);
					JOptionPane.showMessageDialog(null,"Enter Valid Name");
					textField.setEditable(true);
				}
				else
				{
					textField.setEditable(true);
				}

			}
		});
		textField.setBounds(210, 189, 355, 49);
		frmPassengerpage.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
			
				char cn = e.getKeyChar();
				if(Character.isDigit(cn)) {
					textField.setEditable(false);
					JOptionPane.showMessageDialog(null,"Enter Valid Name");
					textField.setEditable(true);
				}
				else
				{
					textField.setEditable(true);
				}
			}
		});
		textField_1.setColumns(10);
		textField_1.setBounds(215, 298, 355, 49);
		frmPassengerpage.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				char cn = e.getKeyChar();
				if(Character.isDigit(cn)) {
					textField.setEditable(false);
					JOptionPane.showMessageDialog(null, "Enter a Valid Passport Number");
					textField.setEditable(true);
				}
				else
				{
					textField.setEditable(true);
				}
			}
		});
		textField_2.setColumns(10);
		textField_2.setBounds(210, 465, 355, 49);
		frmPassengerpage.getContentPane().add(textField_2);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\koushik\\OneDrive\\Pictures\\Saved Pictures\\srulogo.png"));
		lblNewLabel.setBounds(657, 42, 138, 56);
		frmPassengerpage.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new bookingsummary_9();
				frmPassengerpage.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(710, 518, 85, 21);
		frmPassengerpage.getContentPane().add(btnNewButton);
	}
}
